package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.Result

class Treino : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_treino)

        val image: ImageView = findViewById(R.id.image)
        val button: Button = findViewById(R.id.button)
        val button2: Button = findViewById(R.id.button2)

        button2.setOnClickListener{
            val intent = Intent(this, Result::class.java)
            startActivity(intent)
        }
    }
}
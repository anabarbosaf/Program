package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    private lateinit var imageView: ImageView
    private lateinit var buttonChangeImage: Button

    private var imageIndex = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        val imageView: ImageView = findViewById(R.id.imageView)
        val buttonChangeImage: Button = findViewById(R.id.buttonChangeImage)
        val button2: Button = findViewById(R.id.button2)

        button2.setOnClickListener{
            val intent = Intent(this, Result::class.java)
            startActivity(intent)
        }

        buttonChangeImage.setOnClickListener {
            changeImage()
        }

    }

    private fun changeImage(){
        val imageName = "image${++imageIndex % 2 + 1}"
        val resourseId = resources.getIdentifier(imageName, "drawable", packageName)
        imageView.setImageResource(resourseId)
    }

}

package br.fiap.form;
import static javax.swing.JOptionPane.*;
import static java.lang.Integer.parseInt;

public class FormAdmin {

	public void menuAdmin() {
		int opcao = 0;
		
		do {
			try {
				opcao = parseInt(showInputDialog(gerarMenuAdmin()));
			}
			catch(NumberFormatException e) {
				showMessageDialog(null, "A opção deve ser um número\n" + e);
			}
			
		} while(opcao != 4);
		
	}

	private String gerarMenuAdmin() {
		String menu = "Escolha uma operação:\n";
		menu += "1. Emitir Bilhete\n";
		menu += "2. Imprimir Bilhete\n";
		menu += "3. Consultar Bilhete\n";
		menu += "4. Sair";
		return menu;
				
	}
	
}

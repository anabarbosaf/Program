package Fontes;

public class MensagemBoasVindas {
	public String nome;
	
	
	
	public MensagemBoasVindas(String nome) {
		super();
		this.nome = nome;
		
	}

	
	public String nomeUsuario() {
		String nomeUsuario = ( nome + "! \nConfira os resultados dos testes no painel JUnit" );
		return nomeUsuario;
	}
	
	
	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String mensagemIncial() {
		
		String mensagemInicial = ("Seja bem vindo a sua calculadora digital");
		return mensagemInicial;
	}
	
	
	
	
	
	
}



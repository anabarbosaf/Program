package Testes;

import static org.junit.Assert.assertEquals;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import Fontes.MensagemBoasVindas;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MensagemBoasVindasTeste {
	 @Test
	  public void t01mensagemInicial() {
		 String mensagemInicial;
		 String mensagemEsperada =  "Seja bem vindo a sua calculadora digital";
		 MensagemBoasVindas msg = new MensagemBoasVindas("Bel");
		 String mensagemReal = msg.mensagemIncial();
		 assertEquals(mensagemEsperada, mensagemReal);
}
	 @Test
	 public void t02mensagemReal() {
		 MensagemBoasVindas msg = new MensagemBoasVindas("Bel");
		 String mensagemEsperada = msg.getNome() + "! \nConfira os resultados dos testes no painel JUnit";
		 String mensagemReal = msg.nomeUsuario();
		 assertEquals(mensagemEsperada, mensagemReal);
	 }
}

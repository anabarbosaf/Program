//
//  ViewController.swift
//  TestePersonagem
//
//  Created by Usuário Convidado on 07/05/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtSerie: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func abrir(_ sender: Any) {
        if txtSerie.text != "" {
            performSegue(withIdentifier: "TelaLoginParaTelaRecebeSegue", sender: nil)
        }
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let t = segue.destination as! UINavigationController
        let vc = t.topViewController as! RecebeViewController
        vc.texto = txtSerie.text!
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    

}

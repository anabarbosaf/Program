//
//  TelaXViewController.swift
//  NavegandoEntreTelas
//
//  Created by Usuário Convidado on 07/05/24.
//

import UIKit

class TelaXViewController: UIViewController {
    
    

    @IBAction func abrirSceneVerde(_ sender: Any) {
        performSegue(withIdentifier: "telaXParaTelaVerdeSegue", sender: nil)
    }
    
    @IBAction func abrirSceneVermelha(_ sender: Any) {
        performSegue(withIdentifier: "telaXParaTelaVermelhaSegue", sender: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "telaXParaTelaVermelhaSegue"{
            let t = segue.destination as! TelaVermelhaViewController
            t.txtLabel = "Conteudo passado da tela X para label da tela vermelha"
        }
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    

}

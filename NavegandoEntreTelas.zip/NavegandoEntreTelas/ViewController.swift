//
//  ViewController.swift
//  NavegandoEntreTelas
//
//  Created by Usuário Convidado on 07/05/24.
//

import UIKit

class ViewController: UIViewController {
    
    

    @IBAction func fechar(_ sender: Any) {
        self.dismiss(animated: true)
    }
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


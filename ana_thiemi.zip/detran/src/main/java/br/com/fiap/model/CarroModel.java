package br.com.fiap.model;

public class CarroModel {
	private int id, ano;
	private String placa, modelo;
	
	
	public CarroModel(int id, int ano, String placa, String modelo) {
		super();
		this.id = id;
		this.ano = ano;
		this.placa = placa;
		this.modelo = modelo;
	}
	
	
	//get e set


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getAno() {
		return ano;
	}


	public void setAno(int ano) {
		this.ano = ano;
	}


	public String getPlaca() {
		return placa;
	}


	public void setPlaca(String placa) {
		this.placa = placa;
	}


	public String getModelo() {
		return modelo;
	}


	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	
	
}

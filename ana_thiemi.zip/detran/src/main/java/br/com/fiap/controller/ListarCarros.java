package br.com.fiap.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import br.com.fiap.model.CarroModel;

@Controller
public class ListarCarros {
	
	@RequestMapping(value="/", method = RequestMethod.GET)
	public String getCarro(Model model) {
		
		ArrayList<CarroModel> carros = new ArrayList<CarroModel>();
		
		carros.add(new CarroModel(1,2000,"ABC1420","Cedan Prata"));
		carros.add(new CarroModel(2,2005,"CDE1230","Captur branco"));
		carros.add(new CarroModel(3,2008,"FGH2507","Idea cinza"));
		
		model.addAttribute("carros", carros);
		return "carros";
	}
}
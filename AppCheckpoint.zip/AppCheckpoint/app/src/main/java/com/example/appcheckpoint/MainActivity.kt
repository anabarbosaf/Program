package com.example.appcheckpoint

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    var users: MutableList<String> = mutableListOf("user1", "user2")
    var passwords: MutableList<String> = mutableListOf("password11", "password2")
    var results: MutableList<String> = mutableListOf("result1", "result2")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val btn = findViewById<Button>(R.id.signupbtn)
        btn.setOnClickListener {
            val user = findViewById<EditText>(R.id.username)
            val userInput = user.text.toString()


            var result = "User successfully registered"
            var bundle = Bundle()

            if (userInput in users) {
                result = "User already registered. Insert the password"


            } else if (userInput.isEmpty() || userInput.equals("")) {
                result = "User empty, type  a valid user"
            }

            else{
                val password = findViewById<EditText>(R.id.password)
                val passwordInput = password.text.toString()

                if(passwordInput.isEmpty() || passwordInput.equals("")){
                    result = "Empty password, type a valid password"
                }

            }


        }
    }
}
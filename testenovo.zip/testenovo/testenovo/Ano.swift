//
//  Ano.swift
//  testenovo
//
//  Created by user261584 on 5/27/24.
//

import Foundation
class Ano: NSObject{
    var anoAtual:Int
    var anoAnterior:Int
    
    init(anoAtual: Int, anoAnterior: Int) {
        self.anoAtual = anoAtual
        self.anoAnterior = anoAnterior
    }
    
    func calcularAno(anoAtual:Int, anoAnterior:Int)->Int{
        let total = anoAtual - anoAnterior
        return total
    }
}

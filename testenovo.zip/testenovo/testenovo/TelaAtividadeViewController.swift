//
//  TelaAtividadeViewController.swift
//  testenovo
//
//  Created by user261584 on 5/27/24.
//

import UIKit

class TelaAtividadeViewController: UIViewController {
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var txtAtual: UITextField!
    

    @IBAction func switchCalcular(_ sender: Any) {
    
    }
    @IBOutlet weak var txtAnterior: UITextField!
    
    @IBAction func calcular(_ sender: Any) {
        if let anoAtualText = txtAtual.text, let anoAnteriorText = txtAnterior.text, let anoAnterior = Int(anoAnteriorText), let anoAtual = Int(anoAtualText){
            
            let model = Ano(anoAtual: anoAtual, anoAnterior: anoAnterior)
            let resultado = model.calcularAno(anoAtual: anoAtual, anoAnterior: anoAnterior)
            let userInfoAlert = UIAlertController(title: " Informacoes", message: " Ano atual: \(anoAtual), Ano anterior: \(anoAnterior), Se passaram \(resultado) anos", preferredStyle: .alert)
            userInfoAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(userInfoAlert, animated: true, completion: nil)
        }else{
            let emptyNameAlert = UIAlertController(title: "Erro", message: " Insira ano atual e anterior", preferredStyle: .alert)
            emptyNameAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(emptyNameAlert, animated: true, completion: nil)
            
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

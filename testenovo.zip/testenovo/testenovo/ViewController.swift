//
//  ViewController.swift
//  testenovo
//
//  Created by user261584 on 5/27/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


package br.com.fiap.model;

public class MarcasModel {
	
	private long idMarca;
	private String nomeMarca;
	
	
	
	public MarcasModel() {
		super();
		
	}



	public MarcasModel(long idMarca, String nomeMarca) {
		super();
		this.idMarca = idMarca;
		this.nomeMarca = nomeMarca;
	}



	public long getIdMarca() {
		return idMarca;
	}



	public void setIdMarca(long idMarca) {
		this.idMarca = idMarca;
	}



	public String getNomeMarca() {
		return nomeMarca;
	}



	public void setNomeMarca(String nomeMarca) {
		this.nomeMarca = nomeMarca;
	}
	
	
	
	
	
	

}

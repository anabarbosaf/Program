package br.com.fiap.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


import br.com.fiap.model.MarcasModel;

@Repository
public class MarcaRepository {
	
	private static final String GET_ALL = "SELECT * FROM TB_MARCA";
	private static final String GET = "SELECT * FROM TB_MARCA WHERE ID_MARCA = ?";
	private static final String SAVE = "INSERT INTO TB_MARCA (NOME_MARCA) VALUES (?)";
	private static final String UPDATE = "UPDATE TB_MARCA SET NOME_MARCA = ? WHERE ID_MARCA = ?";
	private static final String DELETE = "DELETE FROM TB_MARCA WHERE ID_MARCA = ?";
	
	
	@Autowired
	public JdbcTemplate jdbcTemplate;
	
	public List<MarcasModel> findAll() {
		List<MarcasModel> marcas = this.jdbcTemplate.query(GET_ALL, 
				new BeanPropertyRowMapper<MarcasModel>(MarcasModel.class));
		
		return marcas;
	}
	
	public MarcasModel findById(long id) {
		MarcasModel marca = this.jdbcTemplate.queryForObject(GET, 
				new BeanPropertyRowMapper<MarcasModel>(MarcasModel.class), id);
		
		return marca;
	}
	
	public void save(MarcasModel marcaModel) {
		this.jdbcTemplate.update(SAVE, marcaModel.getNomeMarca());
	}
	
	public void update(MarcasModel marcaModel) {
		this.jdbcTemplate.update(UPDATE, marcaModel.getNomeMarca(), marcaModel.getIdMarca());
	}
	
	public void deleteById(long id) {
		this.jdbcTemplate.update(DELETE, id);
	}

}

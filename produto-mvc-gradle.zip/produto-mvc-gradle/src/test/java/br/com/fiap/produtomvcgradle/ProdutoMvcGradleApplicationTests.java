package br.com.fiap.produtomvcgradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdutoMvcGradleApplicationTests {

	@Test
	void contextLoads() {
	}

}

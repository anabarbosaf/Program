package br.com.fiap.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;


import br.com.fiap.model.MarcaModel;

public class MarcaRepository {

	private static final String GET_ALL = "SELECT * FROM TB_MARCA";
	private static final String GET = "SELECT * FROM TB_MARCA M INNER JOIN TB_PRODUTO P"
			+ " ON P.ID_MARCA = M.ID_MARCA where M.ID_MARCA = ?";
	private static final String SAVE = "INSERT INTO TB_MARCA (NOME_MARCA) VALUES (?)";
	private static final String UPDATE = "UPDATE TB_MARCA SET NOME_MARCA = ? WHERE ID_MARCA = ?";
	private static final String DELETE = "DELETE FROM TB_MARCA WHERE ID_MARCA = ?";
	
	@Autowired
	public JdbcTemplate jdbcTemplate;
	
	public List<MarcaModel> findAll() {
		List<MarcaModel> categorias = this.jdbcTemplate.query(GET_ALL, 
				new BeanPropertyRowMapper<MarcaModel>(MarcaModel.class));
		
		return categorias;
		
	}
	
	public MarcaModel findById(long id) {
		MarcaModel categoria = this.jdbcTemplate.queryForObject(GET, 
				new BeanPropertyRowMapper<MarcaModel>(MarcaModel.class), id);
		return categoria;
	}
	
	public void save(MarcaModel categoriaModel) {
		this.jdbcTemplate.update(SAVE, 
				categoriaModel.getNomeMarca());
		
	}
	
	public void update(MarcaModel categoriaModel) {
		this.jdbcTemplate.update(UPDATE, 
				categoriaModel.getNomeMarca(),
				categoriaModel.getIdMarca());
	}

	
	public void deleteById(long id) {
		this.jdbcTemplate.update(DELETE, id);
	}
}

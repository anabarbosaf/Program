package com.example.changeimage

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView

class ChangeImage : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var buttonChangeImage: Button

    private var imageIndex = 1



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_image)

        imageView = findViewById(R.id.imageView)
        buttonChangeImage = findViewById(R.id.buttonChangeImage)

        buttonChangeImage.setOnClickListener{
            changeImage()
        }
    }

    private fun changeImage(){
        val imageName = "image${++imageIndex % 2 + 1}"
        val resourseId = resources.getIdentifier(imageName, "drawable", packageName)
        imageView.setImageResource(resourseId)
    }

}
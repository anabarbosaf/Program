//
//  ViewController.swift
//  CP2
//
//  Created by Usuário Convidado on 10/05/24.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var lblNome: UITextField!
    
    @IBOutlet weak var stpIdade: UIStepper!
    @IBOutlet weak var lblIdade: UILabel!
    
    @IBOutlet weak var segRisco: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func mudarIndice(_ sender: Any) {
        switch segRisco.selectedSegmentIndex {
        case 0:
            print("solteiro")
        case 1:
            print("casado")
        case 2:
            print("Status: \(segRisco.titleForSegment(at: segRisco.selectedSegmentIndex)!)")
        default:
            break
        }
    }
    @IBAction func mudarValorIdade(_ sender: Any) {
        lblIdade.text = "\(Int(stpIdade.value))"
    }
    
    @IBAction func mudarValorSwitch(_ sender: UISwitch) {
        print(sender.isOn)
    }
    
    @IBAction func avancar(_ sender: Any) {
        var tipo:String = segRisco.titleForSegment(at: segRisco.selectedSegmentIndex)!
        var msg:String = " Nome: \(lblNome.text!), idade: \(lblIdade.text!), status: \(tipo)"
        
        let alerta = UIAlertController(
            title: "Descricao",
            message: msg,
            preferredStyle: UIAlertController.Style.alert)
        alerta.addAction(UIAlertAction(
            title: "oK",
            style: UIAlertAction.Style.default))
        
        present(alerta, animated: true)
    }
    
    
    @IBAction func tela2(_ sender: Any) {
            performSegue(withIdentifier: "TelaLoginParaTelaRecebeSegue", sender: nil)
    }
    

}

